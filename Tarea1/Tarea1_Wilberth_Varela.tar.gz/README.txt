Instituto Tecnológico de Costa Rica
Escuela de Ingeniería Electrónica

Profesor:  Dr. Pablo Alvarado Moya

CE-5201 Procesamiento y Análisis de Imágenes Digitales
I Semestre 2018


Wilberth Varela Guillén
2013053795

Instrucciones para ejecutar el programa:

1). Descomprimir el .tar.gz

2). Entrar a la carpeta Tarea1

3). Entrar a la carpeta build

4). Abrir una consola desde esta carpeta

5). Escribir el comando: "make"

6). Escribir el comando: "./showImage nombre_de_la_imagen", como ejemplo se utiliza lena entonces el comando seria: "./showImage lena.jpg"

